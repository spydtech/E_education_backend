package com.Eonline.Education.Request;

import lombok.Data;

@Data
public class GoogleAuthRequest {
    private String token;
}
