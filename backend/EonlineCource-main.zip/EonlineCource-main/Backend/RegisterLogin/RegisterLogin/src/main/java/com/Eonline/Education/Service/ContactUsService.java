package com.Eonline.Education.Service;

import com.Eonline.Education.modals.ContactUs;

public interface ContactUsService {
    ContactUs saveContactDetails(ContactUs contactUs);
}