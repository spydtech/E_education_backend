package com.Eonline.Education.repository;

import com.Eonline.Education.modals.ContactUs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactUsRepository extends JpaRepository<ContactUs,Integer> {
}
