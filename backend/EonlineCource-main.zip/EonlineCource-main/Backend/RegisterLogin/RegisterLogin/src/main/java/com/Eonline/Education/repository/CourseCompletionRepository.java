package com.Eonline.Education.repository;

import com.Eonline.Education.modals.CourseCompletion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseCompletionRepository extends JpaRepository<CourseCompletion,Long> {
}
