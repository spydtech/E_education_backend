package com.Eonline.Education.repository;

import com.Eonline.Education.modals.TaskDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskDetailsRepository extends JpaRepository<TaskDetails,Long> {
}
