package com.Eonline.Education.response;

import lombok.Data;

@Data
public class CourseDetailResponse {
    private String courseName;
    private Double coursePrice;
    private String courseDuration;
}
