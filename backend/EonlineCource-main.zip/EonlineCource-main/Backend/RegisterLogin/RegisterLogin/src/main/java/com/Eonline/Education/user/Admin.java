package com.Eonline.Education.user;

public class Admin {
}
