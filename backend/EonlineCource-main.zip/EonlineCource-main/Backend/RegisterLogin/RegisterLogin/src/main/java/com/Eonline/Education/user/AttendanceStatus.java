package com.Eonline.Education.user;

public enum AttendanceStatus {
    CHECKIN,
     CHECKOUT
}
