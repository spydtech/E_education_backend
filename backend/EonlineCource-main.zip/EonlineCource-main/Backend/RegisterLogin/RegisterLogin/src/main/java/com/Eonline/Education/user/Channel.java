package com.Eonline.Education.user;

public enum Channel {
    CHAT,
    EMAIL
}
