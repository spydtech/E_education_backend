package com.Eonline.Education.user;

public enum OrderStatus {
    PENDING,
    PLACED,
    CONFIRMED,

    CANCELLED
}