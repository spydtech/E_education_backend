package com.Eonline.Education.user;

public enum PaymentStatus {

    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}