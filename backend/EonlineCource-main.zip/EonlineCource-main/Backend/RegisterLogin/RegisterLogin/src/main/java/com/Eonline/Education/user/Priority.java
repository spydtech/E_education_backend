package com.Eonline.Education.user;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
}
