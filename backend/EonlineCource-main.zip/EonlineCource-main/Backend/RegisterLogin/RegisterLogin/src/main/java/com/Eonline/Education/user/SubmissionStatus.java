package com.Eonline.Education.user;

public enum SubmissionStatus {
    SUBMITTED,
    PENDING
}
