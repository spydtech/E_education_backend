package com.Eonline.Education.user;

public enum TaskStatus {
    ACCEPTED,
    REJECTED,
    PENDING
}
