package com.Eonline.Education.user;

public enum Theme {
    LIGHT,
    DARK,
    BLUE,
    GREEN
}
