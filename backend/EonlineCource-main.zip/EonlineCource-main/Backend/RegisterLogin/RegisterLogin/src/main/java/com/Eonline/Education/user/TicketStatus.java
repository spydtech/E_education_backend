package com.Eonline.Education.user;

public enum TicketStatus {
    PENDING,
    RESOLVED,
    CLOSED,
    CREATED


}
