package com.Eonline.Education.user;

public enum TicketType {

    PAYMENT_RELATED,
    COURSE_RELATED,
    OTHER_SERVICE,
    TECHNICAL_ISSUE; // For trainers only

}
