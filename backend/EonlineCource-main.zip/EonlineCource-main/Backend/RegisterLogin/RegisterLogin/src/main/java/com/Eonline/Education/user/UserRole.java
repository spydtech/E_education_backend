package com.Eonline.Education.user;

public enum UserRole {
    ADMIN,
    CUSTOMER,

}
