package com.Eonline.Education.user;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
