package com.Eonline.Education.user;

public enum VideoStatus {
    VERIFYING,
    NEW,
    PUBLISHED,
    DELETED
}
